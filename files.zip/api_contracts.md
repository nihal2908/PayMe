# API Contracts — Payments Processing System

Base: `/api/v1`
Auth: none — single user assumed for v1, no Bearer token required.
Errors use a single envelope. Version the path, never the payload.

## Error envelope

```json
{
  "timestamp": "2026-08-04T09:14:22Z",
  "path": "/api/v1/payments",
  "code": "INVALID_AMOUNT",
  "message": "Amount must be greater than 0",
  "fieldErrors": [{ "field": "amount", "message": "must be > 0" }],
  "traceId": "b1f2c3d4"
}
```

## Error codes

| Code | HTTP Status | Meaning |
|------|-------------|---------|
| VALIDATION_FAILED | 400 | General payload validation failure |
| INVALID_AMOUNT | 400 | Amount is zero, negative, over the limit, or has too many decimals |
| INVALID_CURRENCY | 400 | Currency is not a supported ISO 4217 code |
| INVALID_ACCOUNT | 400 | Source/destination account invalid or doesn't exist |
| INSUFFICIENT_FUNDS | 400 | Simulated source account balance check failed |
| DUPLICATE_PAYMENT | 409 | (Reserved — in practice duplicates return 200 with the existing payment, see POST /payments) |
| INVALID_STATUS_TRANSITION | 400 | Requested transition is not in the allowed set |
| PAYMENT_NOT_FOUND | 404 | Payment ID does not exist |
| PROCESSING_ERROR | 500 | Internal error during simulated processing |
| NETWORK_ERROR | 503 | Simulated communication failure during the "send" stage |

## POST /payments

Creates a payment and (in this training system) synchronously drives it
through validation and simulated processing to its terminal status.

Headers: `Idempotency-Key: <client-generated string>` (required)

Request
```json
{
  "amount": 250.00,
  "currency": "USD",
  "sourceAccountId": 1,
  "destinationAccountId": 2,
  "reference": "Invoice 4471"
}
```

201 (new payment created)
```json
{
  "id": 9001,
  "status": "COMPLETED",
  "amount": 250.00,
  "currency": "USD",
  "sourceAccountId": 1,
  "destinationAccountId": 2,
  "reference": "Invoice 4471",
  "errorCode": null,
  "errorDescription": null,
  "createdAt": "2026-08-04T09:14:22Z",
  "updatedAt": "2026-08-04T09:14:22Z"
}
```

201 (created, but ended in FAILED — still 201, the resource was created)
```json
{
  "id": 9002,
  "status": "FAILED",
  "amount": -5.00,
  "currency": "USD",
  "sourceAccountId": 1,
  "destinationAccountId": 2,
  "errorCode": "INVALID_AMOUNT",
  "errorDescription": "Amount must be greater than 0",
  "createdAt": "2026-08-04T09:15:01Z",
  "updatedAt": "2026-08-04T09:15:01Z"
}
```

200 (Idempotency-Key already used — existing payment returned, no new record)
```json
{ "id": 9001, "status": "COMPLETED", "...": "same shape as above" }
```

400  VALIDATION_FAILED / INVALID_ACCOUNT / INVALID_CURRENCY — malformed request
     (missing Idempotency-Key header, missing required field, bad account ref)

## GET /payments/{id}

200
```json
{ "id": 9001, "status": "COMPLETED", "...": "same shape as POST response" }
```
404  PAYMENT_NOT_FOUND

## GET /payments

Query: `status`, `page=0`, `size=20`, `sort=createdAt,desc`

200
```json
{
  "content": [ { "id": 9001, "status": "COMPLETED", "...": "..." } ],
  "page": 0,
  "size": 20,
  "totalElements": 134
}
```

## GET /payments/{id}/history

200
```json
{
  "paymentId": 9001,
  "history": [
    { "fromStatus": null,       "toStatus": "CREATED",   "errorCode": null,           "createdAt": "2026-08-04T09:14:22.100Z" },
    { "fromStatus": "CREATED",  "toStatus": "VALIDATED", "errorCode": null,           "createdAt": "2026-08-04T09:14:22.140Z" },
    { "fromStatus": "VALIDATED","toStatus": "SENT",      "errorCode": null,           "createdAt": "2026-08-04T09:14:22.180Z" },
    { "fromStatus": "SENT",     "toStatus": "COMPLETED", "errorCode": null,           "createdAt": "2026-08-04T09:14:22.220Z" }
  ]
}
```
404  PAYMENT_NOT_FOUND

## PATCH /payments/{id}/status

Manual/explicit transition endpoint — used by admin tooling and to
demonstrate and test transition validation directly (FR-LIF-02).

Request
```json
{ "toStatus": "FAILED", "errorCode": "PROCESSING_ERROR", "errorDescription": "Manual override" }
```

200 — transition applied, updated payment returned
400  INVALID_STATUS_TRANSITION — requested transition not in the allowed set
404  PAYMENT_NOT_FOUND

## Conventions

- Times are ISO-8601 UTC with millisecond precision. The server is the
  only clock that matters.
- Money is always a JSON number with up to 2 decimal places, never a
  string.
- No endpoint returns a raw JPA entity — DTOs only.
- Every endpoint is documented in Swagger/OpenAPI with an example
  request and response (FR-DOC-01).
- `Idempotency-Key` is required on `POST /payments` only; all other
  endpoints are naturally idempotent (GET) or explicitly transition-
  checked (PATCH).
