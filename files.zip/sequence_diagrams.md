# Sequence Diagrams — Payments Processing System

## SD-01 Create a payment and process it to completion (happy path)

  Client     API      PaymentSvc   ValidationSvc  LifecycleSvc   DB
   │          │            │             │              │        │
   ├─POST /payments ──────►│             │              │        │
   │  (Idempotency-Key)    │             │              │        │
   │          ├─check idempotency key ──────────────────────────►│
   │          │◄─────────────────────not found──────────────────┤
   │          ├─insert payment, status=CREATED ─────────────────►│
   │          │◄────────────────────────saved──────────────────┤
   │          ├─validate()─►│             │              │        │
   │          │◄──valid─────┤             │              │        │
   │          ├─transition(CREATED→VALIDATED)─────────────►│        │
   │          │             │             │  ├─write status + history row►│
   │          │             │             │  │◄─committed────────┤
   │          ├─transition(VALIDATED→SENT)──────────────────►│        │
   │          │             │             │  ├─write status + history row►│
   │          ├─transition(SENT→COMPLETED)──────────────────►│        │
   │          │             │             │  ├─write status + history row►│
   │◄─201 {id, status:COMPLETED} ─────────┤             │        │

Notes
- All three transitions happen within the same request in this
  training system (processing is simulated, not asynchronous).
- Each transition writes its own history row in the same DB
  transaction as the status update — a status is never visible without
  its corresponding audit entry.
- If any step fails, the flow moves to SD-03 instead of continuing.

## SD-02 Duplicate submission (idempotency)

  Client        API           IdempotencySvc      DB
   │             │                  │              │
   ├─POST /payments (key=IK-001)───►│              │
   │             ├─check key ──────────────────────►│
   │             │◄──────────not found───────────────┤
   │             ├─create payment PMT-500──────────►│
   │◄─201 {id:PMT-500, status:CREATED}──┤              │
   │
   │   ... client times out and retries ...
   │
   ├─POST /payments (key=IK-001)───►│              │
   │             ├─check key ──────────────────────►│
   │             │◄──────────found: PMT-500──────────┤
   │◄─200 {id:PMT-500, status:<current>}─┤              │

Notes
- The second call never reaches PaymentService's create path — it is
  short-circuited by IdempotencySvc.
- HTTP 200 (not 201) signals "this already existed," so the client can
  tell the two cases apart.

## SD-03 Validation failure

  Client     API      ValidationSvc   LifecycleSvc     DB
   │          │             │              │            │
   ├─POST /payments ───────►│              │            │
   │          ├─insert payment, status=CREATED ─────────►│
   │          ├─validate()─►│              │            │
   │          │◄─invalid: amount <= 0 (INVALID_AMOUNT)──┤
   │          ├─transition(CREATED→FAILED, code=INVALID_AMOUNT)─►│
   │          │             │              ├─write status + history►│
   │◄─201 {id, status:FAILED, errorCode:INVALID_AMOUNT}──┤

Notes
- A validation failure still returns 201 — the payment resource itself
  was created successfully; it simply landed in status FAILED. The
  error is inside the resource, not the HTTP envelope.
- The history row for this FAILED entry carries the error code and a
  human-readable description (FR-ERR-02).

## SD-04 Rejected manual status transition

  Client        API        LifecycleSvc        DB
   │             │               │              │
   ├─PATCH /payments/PMT-500/status {to: CREATED} (from COMPLETED)
   │             ├─load current status ────────►│
   │             │◄────────────COMPLETED─────────┤
   │             ├─check transition table: COMPLETED→CREATED?
   │             │◄─not in allowed set────────────┤
   │◄─400 {code: INVALID_STATUS_TRANSITION}──────┤

Notes
- No DB write occurs for a rejected transition — the payment's status
  and history are left completely untouched.
- The same check runs identically whether the caller is the front end
  or a direct API client (FR-LIF-02).
