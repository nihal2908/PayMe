# UI Wireframes — Payments Processing System

Keep low-fidelity. The goal is agreed layout and field order, not
visuals. Store PNG/Figma exports beside this file and reference them
by name.

## W-01 Create Payment  (desktop, React SPA)

┌──────────────────────────────────────────────────────────┐
│  PAYMENTS — New Payment                                  │
├──────────────────────────────────────────────────────────┤
│  Source account *       [ ACC-0001            ▾ ]        │
│  Destination account *  [ ACC-0002            ▾ ]        │
│  Amount *                [ 250.00              ]  USD ▾  │
│  Currency *               [ USD ▾ ]                       │
│  Reference (optional)    [ Invoice 4471          ]        │
│                                                            │
│                    [   C R E A T E   P A Y M E N T   ]   │
└──────────────────────────────────────────────────────────┘
Notes: one primary action. Amount field has focus on load.
Submit button is disabled while the request is in flight (prevents
accidental double-submit — client-side idempotency key is generated
once, on page load, and reused for retries of the same form
submission).
Errors appear inline under the field, in red (FR-FE-01).

## W-02 Payment Details  (colour is the message)

┌──────────────────────────────────────────────────────────┐
│  Payment #9001                          [● COMPLETED]    │
├──────────────────────────────────────────────────────────┤
│  Amount:        250.00 USD                                │
│  Source:        ACC-0001                                  │
│  Destination:   ACC-0002                                  │
│  Reference:     Invoice 4471                               │
│  Created:       2026-08-04 09:14:22                        │
├──────────────────────────────────────────────────────────┤
│  Status history                                            │
│  ○ CREATED     09:14:22.100                                 │
│  ○ VALIDATED   09:14:22.140                                 │
│  ○ SENT        09:14:22.180                                 │
│  ● COMPLETED   09:14:22.220                                 │
└──────────────────────────────────────────────────────────┘

Failed payment variant:
┌──────────────────────────────────────────────────────────┐
│  Payment #9002                             [● FAILED]     │
├──────────────────────────────────────────────────────────┤
│  Amount:        -5.00 USD                                  │
│  ⚠ INVALID_AMOUNT — Amount must be greater than 0          │
├──────────────────────────────────────────────────────────┤
│  Status history                                             │
│  ○ CREATED   09:15:01.000                                   │
│  ● FAILED    09:15:01.040   INVALID_AMOUNT                  │
└──────────────────────────────────────────────────────────┘

Notes: Green badge = COMPLETED, yellow = CREATED/VALIDATED/SENT
(in-progress), red = FAILED. Error code + description are visible
without an extra click, in plain language (FR-FE-02, FR-FE-03, FR-FE-05).

## W-03 Payment List

┌──────────────────────────────────────────────────────────────┐
│ Payments                    Status [ All ▾ ]     [Search: ID/ref] │
├──────────┬───────────┬──────────┬────────────┬────────────────┤
│ ID       │ Amount    │ Currency │ Status     │ Created        │
├──────────┼───────────┼──────────┼────────────┼────────────────┤
│ 9001     │ 250.00    │ USD      │ ● COMPLETED│ 09:14:22       │
│ 9002     │ -5.00     │ USD      │ ● FAILED   │ 09:15:01       │
│ 9003     │ 1,000.00  │ EUR      │ ● SENT     │ 09:16:40       │
└──────────┴───────────┴──────────┴────────────┴────────────────┘
Notes: clicking a row opens W-02. Status filter and search combine
(AND). Colour-coded status dot matches W-02 (FR-FE-04).

## Navigation

  Dashboard → { New Payment | Payment List }
  Payment List → (click row) → Payment Details

No login screen and no role-based navigation in v1 — single user
assumed, per business_requirement.md.
